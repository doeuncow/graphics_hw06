#include "Camera.h"
#include "transform.hpp"

using namespace std;

//위치벡터와 방향벡터 사용하기

const kmuvcl::math::vec3f Camera::center_position() const
{
  kmuvcl::math::vec3f center_position(position_(0) + front_dir_(0),
                 position_(1) + front_dir_(1),
                 position_(2) + front_dir_(2));
  return center_position;
}

// TODO: fill up the following functions properly
void Camera::move_forward(float delta)
{
  position_(0) = position_(0) + delta * front_dir_(0);
  position_(1) = position_(1) + delta * front_dir_(1);
  position_(2) = position_(2) + delta * front_dir_(2);
  //position_ = position_ + delta * front_dir_;
}

//위치 + 벡터 = 위치
void Camera::move_backward(float delta)
{
  position_(0) = position_(0) - delta * front_dir_(0);
  position_(1) = position_(1) - delta * front_dir_(1);
  position_(2) = position_(2) - delta * front_dir_(2);
  //position_ = position_ - delta * front_dir_;
}

void Camera::move_left(float delta)
{
  position_(0) = position_(0) - delta * right_dir_(0);
  position_(1) = position_(1) - delta * right_dir_(1);
  position_(2) = position_(2) - delta * right_dir_(2);
  //position_ = position_ - delta * right_dir_;
}

void Camera::move_right(float delta)
{
  position_(0) = position_(0) + delta * right_dir_(0);
  position_(1) = position_(1) + delta * right_dir_(1);
  position_(2) = position_(2) + delta * right_dir_(2);
  // position_ = position_ + delta * right_dir_;
}

void Camera::rotate_left(float delta)
{
  //회전은 front_dir_와 right_dir_ 둘 다 움직인다.

  kmuvcl::math::mat4x4f rotateMat; //회전 '행렬'은
  rotateMat =  kmuvcl::math::rotate(delta, up_dir_(0), up_dir_(1), up_dir_(2)); //rotate함수가 반환하는 행렬이다.(4X4행렬)

  //front_dir_는 3차원 벡터이므로
  kmuvcl::math::vec4f vec_front(front_dir_(0), front_dir_(1), front_dir_(2)); //4차원벡터로 다시 정의한후
  vec_front = rotateMat * vec_front; //회전행렬 * front벡터 (행렬(배열)곱셈이다.))

  front_dir_(0) = vec_front(0); //3차원 front_dir_에 값을 갱신해준다.
  front_dir_(1) = vec_front(1);
  front_dir_(2) = vec_front(2);

  //right_dir_도 똑같이 해준다.
  kmuvcl::math::vec4f vec_right(right_dir_(0), right_dir_(1), right_dir_(2)); //4차원벡터로 다시 정의한후
  vec_right = rotateMat * vec_right; //회전행렬 * right벡터 (행렬(배열)곱셈이다.))
  right_dir_(0) = vec_right(0); //3차원 right_dir_에 값을 갱신해준다.
  right_dir_(1) = vec_right(1);
  right_dir_(2) = vec_right(2);

}

void Camera::rotate_right(float delta)
{  //회전은 front_dir_와 right_dir_ 둘 다 움직인다.

  kmuvcl::math::mat4x4f rotateMat; //회전 '행렬'은
  rotateMat =  kmuvcl::math::rotate(delta, up_dir_(0), up_dir_(1), up_dir_(2)); //rotate함수가 반환하는 행렬이다.(4X4행렬)

  //front_dir_는 3차원 벡터이므로
  kmuvcl::math::vec4f vec_front(front_dir_(0), front_dir_(1), front_dir_(2)); //4차원벡터로 다시 정의한후
  vec_front = rotateMat * vec_front; //회전행렬 * front벡터 (행렬(배열)곱셈이다.))
  front_dir_(0) = vec_front(0); //3차원 front_dir_에 값을 갱신해준다.
  front_dir_(1) = vec_front(1);
  front_dir_(2) = vec_front(2);

  //right_dir_도 똑같이 해준다.
  kmuvcl::math::vec4f vec_right(right_dir_(0), right_dir_(1), right_dir_(2)); //4차원벡터로 다시 정의한후
  vec_right = rotateMat * vec_right; //회전행렬 * right벡터 (행렬(배열)곱셈이다.))
  right_dir_(0) = vec_right(0); //3차원 right_dir_에 값을 갱신해준다.
  right_dir_(1) = vec_right(1);
  right_dir_(2) = vec_right(2);

}
